import prompt
import random


def greeting():
    print('Welcome to the Brain Games!')
    name = prompt.string('May I have your name? ')
    print('Hello, {}!'.format(name))
    return name

def random_number():
    i = random.randint(1, 99)
    return i

def request_answer():
    answer = prompt.string('Your answer: ')
    return answer

#def process(task):
#    try = 1
#    while try <= 4:
#        if task:

def response_to_user(name, user_answer, is_answer_correct):
    index = 0
    number_of_rounds = 3
    while index < number_of_rounds:
        if is_answer_correct:
            index += 1
        else:
            print("{} is wrong answer ;(. Correct answer was XX".format(user_answer))
            print("Let's try again, {}!".format(name))
            break
        print('Congratulations, {}!'.format(name))


def get_math_symbol():
    math_symbols = [+, -, *]
    index = random.randint(0, 2)
    return math_symbols(index)
