import prompt
from brain_games.games import functions

def start():
    name = functions.greeting()
    print('What is the result of the expression?')
    right_answer = make_question()
    user_answer = functions.request_answer()
    is_answer_correct = check_user_answer(right_answer, user_answer)
    process(name, user_answer, right_answer, is_answer_correct)    


def make_question():
    random_number1 = functions.random_number()
    random_number2 = functions.random_number()
    random_math_symbol = functions.get_math_symbol()
    print('Question: {} {} {}'.format(random_number1, random_number2, random_math_symbol))
    result = calculation(random_number1, random_number2, rando    m_math_symbol)
    return result


def calculation(first_number, second_number, math_symbol):
    result = first_number math_symbol second_number
    return result


def check_user_answer(right_answer, user_answer):
    if right_answer = user_answer:
        print ('Correct!')
        return True
    return False


def process (name, user_answer, right_answer, is_answer_correct):
    index = 0
    number_of_rounds = 3
    while index < number_of_rounds:
        if is_answer_correct:
            index += 1
        else:
            print("{} is wrong answer ;(. Correct answer was {}".format(user_answer, right_answer))
            print("Let's try again, {}!".format(name))
            break
        print('Congratulations, {}!'.format(name))

