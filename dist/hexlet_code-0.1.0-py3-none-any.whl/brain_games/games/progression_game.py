from brain_games.games import functions


def start():
    name = functions.greeting()
    print('What number is missing in the progression?')
    make_question()
    

def make_question():
    line_length = functions.random_number(5, 10)
    first_number = functions.random_number(1, 30)
    step = functions.random_number(1, 9)
    hidden_element = functions.random_number(0, line_length - 1)
    numbers_list = [first_number]
    number_of_elements = len(numbers_list)
    while number_of_elements < line_length:
        first_number = first_number + step
        numbers_list.append(first_number)
    numbers_list.insert(hidden_element, '..')
    a = numbers_list(map(int, input().split()))
    print(*a)
       
