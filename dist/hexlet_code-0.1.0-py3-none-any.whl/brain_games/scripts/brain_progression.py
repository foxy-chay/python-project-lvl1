from brain_games.games import progression_game


def main():
    progression_game.start()


if __name__ == '__main__':
    main()
