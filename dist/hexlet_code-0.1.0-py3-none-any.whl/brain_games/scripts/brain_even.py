#!/usr/bin/env python3

from .. import even_odd_game


def main():
    even_odd_game.greeting()


if __name__ == '__main__':
    main()

