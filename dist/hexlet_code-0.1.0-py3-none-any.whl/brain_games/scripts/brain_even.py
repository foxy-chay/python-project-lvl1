#!/usr/bin/env python3

from brain_games.games import even_odd_game


def main():
    even_odd_game.start()


if __name__ == '__main__':
    main()
