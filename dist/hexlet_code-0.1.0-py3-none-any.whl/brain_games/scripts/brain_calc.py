from brain_games.games import calc_game


def main():
    calc_game.start()


if __name__ == '__main__':
    main()
